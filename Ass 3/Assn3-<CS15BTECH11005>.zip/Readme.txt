1. Locate Directory
2. Enter command g++ filename.cpp -lpthread
3. ./a.out